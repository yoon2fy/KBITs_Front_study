import { createApp } from 'vue'
import App from './App4.vue'

createApp(App).mount('#app')